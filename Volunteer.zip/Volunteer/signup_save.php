<?php
include("connect/db.php");

	$name=$_POST["name"];
	$email=$_POST["email"];
	$contactno=$_POST["contactno"];
	$password=$_POST["password"];
	$utype=$_POST["utype"];
	$stat='Active';

	
	if($utype=="Volunteer")
	{
	$sql = "insert into volunteer(name,email,contactno,password,utype,stat)values('$name','$email','$contactno','$password','$utype','$stat')";
	$q1 = $db->prepare($sql);
	$q1->execute();
	}
	else
	{
	$sql = "insert into user(name,email,contactno,password,utype,stat)values('$name','$email','$contactno','$password','$utype','$stat')";
	$q1 = $db->prepare($sql);
	$q1->execute();	
	}
	header("location:login.php");
?>

