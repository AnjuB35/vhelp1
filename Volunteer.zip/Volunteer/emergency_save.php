<?php
include("connect/db.php");

	$name=$_POST["name"];
	$email=$_POST["email"];
	$contno1=$_POST["contno1"];
	$contno2=$_POST["contno2"];
	$neds=$_POST["neds"];
	$date=date("Y-m-d");
	
	$sql = "insert into emergency(name,email,contno1,contno2,neds,date)values('$name','$email','$contno1','$contno2','$neds','$date')";
	$q1 = $db->prepare($sql);
	$q1->execute();	
	header("location:index.php");
?>

