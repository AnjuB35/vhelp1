<?php
	//Start session
	session_start();
	include("connect/db.php");
	//Sanitize the POST values
	$email = $_POST['email'];
	$password = $_POST['password'];
	//Create query
	$qry = $db->prepare("SELECT * FROM admin WHERE username='$email' and password='$password' and utype='Admin'");
	$qry->execute();
	$count = $qry->rowcount();
	
	$qrydprt = $db->prepare("SELECT * FROM department WHERE email='$email' and password='$password' and utype='Department'");
	$qrydprt->execute();
	$countdprt = $qrydprt->rowcount();
	
	$qryvolntr = $db->prepare("SELECT * FROM volunteer WHERE email='$email' and password='$password' and utype='Volunteer' and stat='Active'");
	$qryvolntr->execute();
	$countvolntr= $qryvolntr->rowcount();
	
	$qryusr = $db->prepare("SELECT * FROM user WHERE email='$email' and password='$password' and utype='User' and stat='Active'");
	$qryusr->execute();
	$countusr = $qryusr->rowcount();
	//Check whether the query was successful or not
	if($count > 0) {
		//Login Successful
		session_regenerate_id();
		$rows = $qry->fetch();
		$_SESSION['SESS_ADMIN_ID'] = $rows['aid'];
		session_write_close();
		header("location:apps/admin/index.php");
		exit();
	}
	if($countdprt > 0) {
		//Login Successful
		session_regenerate_id();
		$rowdprt = $qrydprt->fetch();
		$_SESSION['SESS_DEPT_ID'] = $rowdprt['dep_id'];
		session_write_close();
		header("location:apps/department/index.php");
		exit();
	}
	else if($countvolntr > 0) {
		//Login Successful
		session_regenerate_id();
		$rowvolntr = $qryvolntr->fetch();
		$_SESSION['SESS_VOL_ID'] = $rowvolntr['voln_id'];
		session_write_close();
		header("location:apps/volunteer/index.php");
		exit();
	}
	else if($countusr > 0) {
		//Login Successful
		session_regenerate_id();
		$rowusr = $qryusr->fetch();
		$_SESSION['SESS_USER_ID'] = $rowusr['user_id'];
		session_write_close();
		header("location:apps/user/index.php");
		exit();
	}
	else 
	{
		//Login failed
		echo "<script>alert('Check Username And Password.'); window.location='login.php'</script>";
		exit();
	}
?>
