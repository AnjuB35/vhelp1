<footer class="main-footer">
	<strong>Vhelp</strong>
</footer>