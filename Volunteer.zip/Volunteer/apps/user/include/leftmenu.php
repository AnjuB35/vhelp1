<aside class="main-sidebar" style="margin-top:-40px;">
	<section class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
           <li>
          		<a href="index.php">
            		<i class="fa fa-dashboard"></i> <span>Dashboard</span>
          		</a>
        	</li>			
           <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Profile</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="profile.php"><i class="fa fa-laptop"></i> Profile</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Department</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="depratment_search.php"><i class="fa fa-laptop"></i> Search</a>
                     </li>                                                                 		                                     
				</ul>
			</li>                          
             <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Helpline</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="helpline_search.php"><i class="fa fa-laptop"></i> Search</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
             <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Request</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="request_register.php"><i class="fa fa-laptop"></i> Request</a>
                        <a href="request_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="request_pending.php"><i class="fa fa-laptop"></i> Pending</a>
                        <a href="request_accept.php"><i class="fa fa-laptop"></i> Accept</a>
                        <a href="request_cancel.php"><i class="fa fa-laptop"></i> Cancel</a>
						<a href="message_send.php"><i class="fa fa-laptop"></i> Message</a>
                     </li>                                                                 		                                     
				</ul>
			</li>
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Complaint</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="complaint_post.php"><i class="fa fa-laptop"></i> Post</a>
                        <a href="complaint_pending.php"><i class="fa fa-laptop"></i> Pending</a>
                        <a href="complaint_forward.php"><i class="fa fa-laptop"></i> Forward</a>
                        <a href="complaint_clear.php"><i class="fa fa-laptop"></i> Clear</a>
                        <a href="complaint_cancel.php"><i class="fa fa-laptop"></i> Cancel</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Missing</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="missing_view.php"><i class="fa fa-laptop"></i> View</a>
                     </li>                                                                 		                                     
				</ul>
			</li>
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Camp</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="camp_search.php"><i class="fa fa-laptop"></i> Search</a>
                     </li>                                                                 		                                     
				</ul>
			</li>
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Notification</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="notification.php"><i class="fa fa-laptop"></i> View</a>
                     </li>                                                                 		                                     
				</ul>
			</li>  
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Feedback</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>                     	
                    	<a href="feedback_send.php"><i class="fa fa-laptop"></i> Send</a>
                        <a href="feedback_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="feedback_reply.php"><i class="fa fa-laptop"></i> Reply</a>
                     </li>                                                                 		                                     
				</ul>
			</li>                
            <li>
                <a href="../../index.php">
                    <i class="fa fa-sign-out"></i> <span>Logout</span>
                </a>
            </li>     
		</ul>
	</section>
</aside>
