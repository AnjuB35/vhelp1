<?php
	include("../auth.php");
	include('../../../connect/db.php');
	
	$departmnt=$_POST["departmnt"];
	$name=$_POST["name"];
	$contactno=$_POST["contactno"];
	$email=$_POST["email"];
	$compl=$_POST["compl"];
	$date=$_POST["date"];
	$stat='pending';
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../complaint/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
$sql = "insert into complaints(departmnt,name,contactno,email,compl,date,photo,stat)values('$departmnt','$name','$contactno','$email','$compl','$date','$photo','$stat')";
$q1 = $db->prepare($sql);
$q1->execute();


header("location:../complaint_post.php");
?>
