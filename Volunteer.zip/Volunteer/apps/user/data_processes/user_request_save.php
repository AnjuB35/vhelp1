<?php
	include("../auth.php");
	include('../../../connect/db.php');
	
	$reqrg_id=$_GET['reqrg_id'];
	$result = $db->prepare("select * from rquest_register where reqrg_id='$reqrg_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name=$row["name"];
		$cntno=$row["cntno"];
		$email=$row["email"];
		$subj=$row["subj"];
		$servce=$row["servce"];
		$dept=$row["dept"];
		$fdate=$row["fdate"];
		$tdate=$row["tdate"];
	}
	
	$user_id=$_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from user where user_id='$user_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$uname=$row["name"];
		$usex=$row["sex"];
		$uage=$row["age"];
		$udistrict=$row["district"];
		$uemail=$row["email"];
		$ucontact=$row["contactno"];
	}
	$stat='pending';
	$rstat='accept';
	
$sql = "insert into rquest_register_accept(name,cntno,email,subj,servce,fdate,tdate,uname,usex,uage,ucontact,udistrict,uemail,stat)values('$name','$cntno','$email','$subj','$servce','$fdate','$tdate','$uname','$usex','$uage','$ucontact','$udistrict','$uemail','$stat')";
$q1 = $db->prepare($sql);
$q1->execute();

$sql = "update rquest_register set runame='$uname',rstat='$rstat' where reqrg_id='$reqrg_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../request_search.php");
?>
