<?php
include("../../../connect/db.php");

	$user_id=$_POST["user_id"];
	$age=$_POST["age"];
	$sex=$_POST["sex"];
	$blgrp=$_POST["blgrp"];
	$addrs=$_POST["addrs"];
	$district=$_POST["district"];
	$location=$_POST["location"];
	$pinocde=$_POST["pinocde"];
	$email=$_POST["email"];
	$contactno=$_POST["contactno"];
	$password=$_POST["password"];
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../user_photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	if($photo=="")
	{
		$sql = "update user set age='$age',blgrp='$blgrp',addrs='$addrs',sex='$sex',district='$district',location='$location',pinocde='$pinocde',email='$email',contactno='$contactno',password='$password' where user_id='$user_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	else
	{
		$sql = "update user set age='$age',blgrp='$blgrp',addrs='$addrs',sex='$sex',district='$district',location='$location',pinocde='$pinocde',email='$email',contactno='$contactno',password='$password',photo='$photo' where user_id='$user_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}

	header("location:../index.php");
?>

