<?php
	include("auth.php");
	include('../../connect/db.php');
	$user_id=$_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from user where user_id='$user_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name=$row["name"];
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Complaint</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Citizen Complaint Clear Information</strong>
                    </div>
                    <div class="table-responsive">
                         <table class="table table-bordered table-hover">       
                         	<thead>
                            	<tr>
									<th>Date</th>                                	
                                    <th>Department</th>
                                    <th>Complaint</th>
                                    <th>Photo</th>
                                    <th>Status</th>    
                                    <th>Date</th>                               
                                </tr>
                            </thead>                   
                           <tbody>  
                           	   <?php
									$result = $db->prepare("select * from  complaints where name='$name' and stat='clear'");
									$result->execute();
									for($i=1; $row = $result->fetch(); $i++)
										{										
											echo"<tr>";						
											echo"<td>".$row["date"]."</td>";
											echo"<td>".$row["departmnt"]."</td>";	
											echo"<td>".$row["compl"]."</td>";	
											echo"<td><a href='../complaint/".$row["photo"]."' target='_blank'><img src='../complaint/".$row["photo"]."' class='img-circle' style='width:30px;'></a></td>";											
											echo"<td>".$row["reply"]."</td>";
											echo"<td>".$row["rdate"]."</td>";											
											echo"</tr>";										
										}
									
							?>	
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>

<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
