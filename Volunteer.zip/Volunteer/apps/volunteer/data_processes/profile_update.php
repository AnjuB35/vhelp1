<?php
include("../../../connect/db.php");

	$voln_id=$_POST["voln_id"];
	$age=$_POST["age"];
	$sex=$_POST["sex"];
	$blgrp=$_POST["blgrp"];
	$addrs=$_POST["addrs"];
	$district=$_POST["district"];
	$location=$_POST["location"];
	$pinocde=$_POST["pinocde"];
	$qulf=$_POST["qulf"];
	$job=$_POST["job"];
	$experincs=$_POST["experincs"];
	$servce=$_POST["servce"];
	$email=$_POST["email"];
	$contactno=$_POST["contactno"];
	$password=$_POST["password"];
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	if($photo=="")
	{
		$sql = "update volunteer set age='$age',sex='$sex',blgrp='$blgrp',addrs='$addrs',district='$district',location='$location',pinocde='$pinocde',qulf='$qulf',job='$job',experincs='$experincs',servce='$servce',email='$email',contactno='$contactno',password='$password' where voln_id='$voln_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	else
	{
		$sql = "update volunteer set age='$age',sex='$sex',blgrp='$blgrp',addrs='$addrs',district='$district',location='$location',pinocde='$pinocde',qulf='$qulf',job='$job',experincs='$experincs',servce='$servce',email='$email',contactno='$contactno',password='$password',photo='$photo' where voln_id='$voln_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}

	header("location:../index.php");
?>

