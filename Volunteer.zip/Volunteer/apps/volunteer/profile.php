<?php
	include("auth.php");
	include('../../connect/db.php');
	$voln_id=$_SESSION['SESS_VOL_ID'];
	$result = $db->prepare("select * from volunteer where voln_id='$voln_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name=$row["name"];
		$sex=$row["sex"];
		$age=$row["age"];
		$blgrp=$row["blgrp"];
		$addrs=$row["addrs"];
		$district=$row["district"];
		$location=$row["location"];
		$pinocde=$row["pinocde"];
		$qulf=$row["qulf"];
		$job=$row["job"];
		$experincs=$row["experincs"];
		$servce=$row["servce"];
		$email=$row["email"];
		$contactno=$row["contactno"];
		$password=$row["password"];	
		$photo=$row["photo"];		
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Profile</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Profile Information Update</strong>
                    </div>
                    <form action="data_processes/profile_update.php" method="post" autocomplete="off" enctype="multipart/form-data">
                    <div class="form-group">
                    	<label>Name</label>
                        	<input type="hidden"  name="voln_id" value="<?php echo $voln_id?>">
                            <input type="text" class="form-control" name="name" value="<?php echo $name?>" readonly>
                    </div>
                    <div class="form-group">
                    	<label>Gender</label>
                               <input type="text" class="form-control" name="sex" value="<?php echo $sex?>">                        	
                    </div>
                     <div class="form-group">
                    	<label>Age</label>
                              <input type="number" class="form-control" name="age" value="<?php echo $age?>">     
                    </div>
                    <div class="form-group">
                    	<label>Blood Group</label>
                        	<select name="blgrp" class="form-control" required>
                            	<option><?php echo $blgrp?></option>
                                <option>O+</option>
                                <option>O-</option>
                                <option>B</option>
                                <option>B+</option>
                                <option>A</option>
                                <option>A+</option>
                            </select>
                    </div>
                    <div class="form-group">
                    	<label>Address</label>
                        	<input type="text" class="form-control" name="addrs" value="<?php echo $addrs?>">
                    </div>                    
                    <div class="form-group">
                    	<label>District</label>
                        	<select name="district" class="form-control" required>
                            	<option><?php echo $district?></option>
                                <option>Palakkad</option>
                                <option>Malapuram</option>
                                <option>Kozhikode</option>
                                <option>Thrissur</option>
                            </select>
                    </div>
                    <div class="form-group">
                    	<label>Location</label>
                        	<input type="text" class="form-control" name="location"  value="<?php echo $location?>">  
                    </div>
                    
                     <div class="form-group">
                    	<label>Pincode</label>
                        	<input type="text" class="form-control" name="pinocde"  value="<?php echo $pinocde?>">  
                    </div>
                     <div class="form-group">
                    	<label>Qualification</label>
                        	<input type="text" class="form-control" name="qulf"  value="<?php echo $qulf?>">  
                    </div>
                     <div class="form-group">
                    	<label>Job</label>
                        	<input type="text" class="form-control" name="job"  value="<?php echo $job?>">  
                    </div>                   
                    <div class="form-group">
                    	<label>Experience</label>
                        	<input type="text" class="form-control" name="experincs"  value="<?php echo $experincs?>">  
                    </div>
                     <div class="form-group">
                    	<label>Service</label>
                        	<input type="text" class="form-control" name="servce"  value="<?php echo $servce?>">  
                    </div>
                    <div class="form-group">
                    	<label>Email</label>
                        	<input type="email" class="form-control" name="email"  value="<?php echo $email?>">  
                    </div>
                    <div class="form-group">
                    	<label>Contact No</label>
              				<input type="text" class="form-control" name="contactno"  value="<?php echo $contactno?>">  
                    </div>                    
                     <div class="form-group">
                    	<label>Password</label>
                        	<input type="password" class="form-control" name="password" value="<?php echo $password?>">  
                    </div>
                    <div class="form-group">
                    	<label>&nbsp;</label>
                        	<img src="../photo/<?php echo $photo?>" class="img-responsive img-circle">
                    </div>
                    <div class="form-group">
                    	<label>Photo</label>
                        	<input type="file" class="form-control" name="photo">
                    </div>                 
                    <div class="row">
                        <div class="col-xs-4 pull-right">
                            <br>
                            <button type="submit" class="btn btn-primary btn-block btn-flat">Update</button>
                        </div>                           
                        <div class="col-xs-4 pull-right">
                            <br>
                            <a href="index.php" class="btn btn-danger btn-block btn-flat">Back</a>
                        </div>
                    </div>
                    <br>
                </form> 
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
</body>
</html>

