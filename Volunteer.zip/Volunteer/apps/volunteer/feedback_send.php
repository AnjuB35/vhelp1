<?php
	include("auth.php");
	include('../../connect/db.php');
	$voln_id=$_SESSION['SESS_VOL_ID'];
	$result = $db->prepare("select * from volunteer where voln_id='$voln_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name = $row['name'];
		$cntno = $row['contactno'];
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Feedback</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Feedback Send</strong>
                    </div>
                    <form method="post" action="data_processes/feedback_save.php" class="forms" autocomplete="off">                          
                        <div class="col-md-6">
                            <label>Name</label>
                                <input type="text"  name="name" class="form-control" value="<?php echo $name?>" readonly>                 
                        </div> 
                        <div class="col-md-6">
                            <label>Contact No</label>
                                <input type="text"  name="cntno" class="form-control"  value="<?php echo $cntno?>" readonly>                  
                        </div> 
                        <div class="col-md-6">
                            <label>Subject</label>
                                <textarea name="subj" class="form-control" rows="6" required></textarea>
                        </div> 
                        <div class="col-md-6">
                            <label>Date</label>
                                <input type="date"  name="sdate" class="form-control">                 
                        </div>                                                                                                   
                        <div class="col-md-6 col-sm-12 col-xs-12" style="float:right">
                            <br>
                            <div class="col-md-6 col-sm-6 col-xs-12 pull-right">
                                <input type="submit" value="Send" class="btn btn-block btn-primary">
                            </div>                          
                        </div>
                    </form>
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
</body>
</html>

