<aside class="main-sidebar" style="margin-top:-40px;">
	<section class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
           <li>
          		<a href="index.php">
            		<i class="fa fa-dashboard"></i> <span>Dashboard</span>
          		</a>
        	</li>			
           <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Profile</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="profile.php"><i class="fa fa-laptop"></i> Profile</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Department</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="department.php"><i class="fa fa-laptop"></i> Register</a>
                        <a href="department_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="depratment_update.php"><i class="fa fa-laptop"></i> Update</a>
                     </li>                                                                 		                                     
				</ul>
			</li>             
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Volunteer</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>                     
                        <a href="volunteer_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="volunteer_permission.php"><i class="fa fa-laptop"></i> Permission</a>
                     </li>                                                                 		                                     
				</ul>
			 </li> 
             <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>User</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>                     
                        <a href="user_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="user_permission.php"><i class="fa fa-laptop"></i> Permission</a>
                     </li>                                                                 		                                     
				</ul>
			 </li> 
              <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Missing</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>                     
                        <a href="missing_view.php"><i class="fa fa-laptop"></i> View</a>
						<a href="missing_register.php"><i class="fa fa-laptop"></i> Register</a>
                     </li>                                                                 		                                     
				</ul>
			 </li>
             <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Helpline</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                        <a href="helpline_register.php"><i class="fa fa-laptop"></i> Register</a>
                        <a href="helpline_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="helpline_remove.php"><i class="fa fa-laptop"></i> Remove</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
             <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Request</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="request_register.php"><i class="fa fa-laptop"></i> Request</a>
                        <a href="request_search.php"><i class="fa fa-laptop"></i> Search</a>
                     </li>                                                                 		                                     
				</ul>
			</li>
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Complaint</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="complaint_pending.php"><i class="fa fa-laptop"></i> Pending</a>
                        <a href="complaint_forward.php"><i class="fa fa-laptop"></i> Forward</a>
                        <a href="complaint_clear.php"><i class="fa fa-laptop"></i> Clear</a>
                        <a href="complaint_cancel.php"><i class="fa fa-laptop"></i> Cancel</a>
                     </li>                                                                 		                                     
				</ul>
			</li> 
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Camp</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="camp_register.php"><i class="fa fa-laptop"></i> Register</a>
                        <a href="camp_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="camp_remove.php"><i class="fa fa-laptop"></i> Remove</a>
                     </li>                                                                 		                                     
				</ul>
			</li>
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Notification</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="notification_send.php"><i class="fa fa-laptop"></i> Send</a>
                        <a href="notification_remove.php"><i class="fa fa-laptop"></i> Remove</a>
                     </li>                                                                 		                                     
				</ul>
			</li>  
            <li class="treeview">
				<a href="#">
					<i class="fa fa-share"></i> <span>Feedback</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
          		<ul class="treeview-menu">                  		
					 <li>
                    	<a href="feedback_search.php"><i class="fa fa-laptop"></i> Search</a>
                        <a href="feedback_reply.php"><i class="fa fa-laptop"></i> Reply</a>
                     </li>                                                                 		                                     
				</ul>
			</li>                
            <li>
                <a href="../../index.php">
                    <i class="fa fa-sign-out"></i> <span>Logout</span>
                </a>
            </li>     
		</ul>
	</section>
</aside>
