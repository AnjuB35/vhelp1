<?php
	include("../auth.php");
	include('../../../connect/db.php');
	
	 $department=$_POST["department"];
	 $pname=$_POST["pname"];
	 $name=$_POST["name"];
	 $sex=$_POST["sex"];
	 $age=$_POST["age"];
	 $addr=$_POST["addr"];
	 $cntno=$_POST["cntno"];
	 $mplace=$_POST["mplace"];
	 $mdate=$_POST["mdate"];
	 $desp=$_POST["desp"];
	 $stat="Pending";
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../missing_people/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
$sql = "insert into messing_people(department,pname,name,sex,age,addr,cntno,mplace,mdate,desp,photo,stat)values('$department','$pname','$name','$sex','$age','$addr','$cntno','$mplace','$mdate','$desp','$photo','$stat')";
$q1 = $db->prepare($sql);
$q1->execute();


header("location:../missing_view.php");
?>
