<?php
include('../../../connect/db.php');
		 
	 $dep_id=$_POST["dep_id"];	 
	
	 $cntno=$_POST["cntno"];	
	 $email=$_POST["email"];
	 $password=$_POST["password"]; 
	
$sql = "update department set cntno='$cntno',email='$email',password='$password' where dep_id='$dep_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../index.php");
?>
