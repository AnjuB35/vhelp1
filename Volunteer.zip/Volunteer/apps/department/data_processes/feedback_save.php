<?php
include("../../../connect/db.php");

	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$subj=$_POST["subj"];
	$sdate=$_POST["sdate"]; 
	
$sql = "insert into feedback(name,cntno,subj,sdate)values('$name','$cntno','$subj','$sdate')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../feedback_send.php");
?>
