<?php
session_start();
if(!isset($_SESSION['SESS_DEPT_ID']) || (trim($_SESSION['SESS_DEPT_ID']) == '')) {
	header("location:../");
	exit();
}

?>
