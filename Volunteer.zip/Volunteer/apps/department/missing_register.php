<?php
	include("auth.php");
	include('../../connect/db.php');
	$dep_id=$_SESSION['SESS_DEPT_ID'];
	$result = $db->prepare("select * from department where dep_id='$dep_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$departmnt = $row['departmnt'];	
		$name = $row['name'];
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Camp</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Camp Register</strong>
                    </div>
                    <form method="post" action="data_processes/missing_save.php" class="forms" autocomplete="off" enctype="multipart/form-data">   
                        <div class="col-md-6">
                            <label>Department</label>
                             <input type="text"  name="department" class="form-control" value="<?php echo $departmnt?>" readonly>
                        </div>  
                        <div class="col-md-6">
                            <label>Post</label>
                                <input type="text"  name="pname" class="form-control" value="<?php echo $name?>" readonly>                  
                        </div> 
                        <div class="col-md-6">
                            <label>Name</label>
                                <input type="text"  name="name" class="form-control" required pattern="[a-zA-Z1 _]{3,50}">                  
                        </div> 
                        <div class="col-md-6">
                            <label>Gender</label>
                               <select name="sex" class="form-control" required>
                               		<option value="">Select</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                               </select>               
                        </div> 
                         <div class="col-md-6">
                            <label>Age</label>
                        		<input type="number" class="form-control" name="age" required min="0">        
                        </div>  
                        <div class="col-md-6">
                            <label>Address</label>
                        		<textarea name="addr" class="form-control" required></textarea> 
                        </div>   
                         <div class="col-md-6">
                            <label>Contact No</label>
                        		<input type="text" class="form-control" name="cntno" equired pattern="[0-9]{10,10}" maxlength="10" minlength="10">        
                        </div>  
                         <div class="col-md-6">
                            <label>Missing Place</label>
                        		<input type="text" class="form-control" name="mplace" required>        
                        </div>                          
                        <div class="col-md-6">
                            <label>Missing Date</label>
                                <input type="date"  name="mdate" class="form-control" required max="<?php echo date("Y-m-d");?>">                  
                        </div>                         
                        <div class="col-md-6">
                            <label>Description</label>
                        		<textarea name="desp" class="form-control" required></textarea>
                        </div>   
                          <div class="col-md-6">
                            <label>Photo</label>
                        		<input type="file" class="form-control" name="photo" required>        
                        </div>                                                                            
                        <div class="col-xs-12 text-right">
                                <br>
                                <input type="submit" value="Submit" class="btn float-right btn-primary">
                            </div>
                    </form>
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
</body>
</html>

