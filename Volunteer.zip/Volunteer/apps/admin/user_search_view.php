<?php
	include("auth.php");
	include('../../connect/db.php');
	$name=$_POST['name'];
	$result = $db->prepare("select * from user where name='$name'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name=$row["name"];
		$sex=$row["sex"];
		$age=$row["age"];
		$blgrp=$row["blgrp"];
		$addrs=$row["addrs"];
		$district=$row["district"];
		$location=$row["location"];
		$pinocde=$row["pinocde"];
		$email=$row["email"];
		$contactno=$row["contactno"];
		$photo=$row["photo"];		
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Profile</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Personal Information</strong>
                    </div>
                    <form>
                    <div class="form-group">
                    	<label>Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo $name?>" readonly>
                    </div>
                    <div class="form-group">
                    	<label>Sex</label>
                        <input type="text" class="form-control" name="sex" value="<?php echo $sex?>" readonly>                        	
                    </div>
                 
                     <div class="form-group">
                    	<label>Age</label>
                        	<input type="number" class="form-control" name="age" value="<?php echo $age?>" readonly>     
                    </div>
                    <div class="form-group">
                    	<label>Blood Group</label>
                        	 <input type="text" class="form-control" name="blgrp" value="<?php echo $blgrp?>" readonly>                         
                    </div>
                    <div class="form-group">
                    	<label>Address</label>
                        	<input type="text" class="form-control" name="addrs" value="<?php echo $addrs?>" readonly>
                    </div>                    
                    <div class="form-group">
                    	<label>District</label>
                        	 <input type="text" class="form-control" name="district" value="<?php echo $district?>" readonly>                         
                    </div>
                    <div class="form-group">
                    	<label>Location</label>
                        	<input type="text" class="form-control" name="location"  value="<?php echo $location?>" readonly>  
                    </div>
                    
                     <div class="form-group">
                    	<label>Pincode</label>
                        	<input type="text" class="form-control" name="pinocde"  value="<?php echo $pinocde?>" readonly>  
                    </div>
                    <div class="form-group">
                    	<label>Email</label>
                        	<input type="email" class="form-control" name="email"  value="<?php echo $email?>" readonly>  
                    </div>
                    <div class="form-group">
                    	<label>Contact No</label>
              				<input type="text" class="form-control" name="contactno"  value="<?php echo $contactno?>" readonly>  
                    </div>                                        
                    <div class="form-group">
                    	<label>&nbsp;</label>
                        	<img src="../user_photo/<?php echo $photo?>" class="img-responsive img-circle">
                    </div>                               
                    <div class="row">                                             
                        <div class="col-xs-4 pull-right">
                            <br>
                            <a href="user_search.php" class="btn btn-danger btn-block btn-flat">Back</a>
                        </div>
                    </div>
                    <br>
                </form> 
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
</body>
</html>

