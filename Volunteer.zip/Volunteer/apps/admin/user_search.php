<?php
include('../../connect/db.php');	
require("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Volunteer</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-xs-8 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Public Search</strong>
                    </div>
                    <form method="post" action="user_search_view.php" class="forms" autocomplete="off">   
                        <div class="col-md-6">
                            <label>Name</label>
                                <input list="name" required class="form-control" name="name" placeholder="Search">
                                <datalist id="name">
                                    <option value="">Select</option> 
                                     <?php
										$result = $db->prepare("SELECT distinct(name) FROM user");
										$result->execute();
										$row_count =  $result->rowcount();
										for($i=0; $rows = $result->fetch(); $i++)
										{
										echo '<option>'.$rows['name'].'</option>';
										}
                                    ?>	                                         					
                                </datalist>            
                        </div>                                                                                 
                        <div class="col-md-6 col-sm-6 col-xs-6" style="float:right">
                            <br>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="submit" value="Search" class="btn btn-block btn-primary">
                            </div>                          
                        </div>
                    </form>
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
</body>
</html>

