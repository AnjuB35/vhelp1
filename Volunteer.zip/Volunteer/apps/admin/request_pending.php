<?php
	include("auth.php");
	include('../../connect/db.php');
	$aid=$_SESSION['SESS_ADMIN_ID'];
	$result = $db->prepare("select * from admin where aid='$aid'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$name=$row["username"];
		
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Volunteer</title>
  <link rel="shortcut icon" href="../bower_components/dist/img/logo.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/ionicons/css/ionicons.min.css"> 
  <link rel="stylesheet" href="../bower_components/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bower_components/dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<?php include("include/header.php");?>
	<?php include("include/leftmenu.php");?>
  	<div class="content-wrapper">
    	<section class="content-header">
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="index.php">Request</a></li>
          </ol>
    	</section>
    	<section class="content">
        	<br>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 well">
                    <div class="alert" style="padding:5px; color:white;">
                        <strong>Request Pending Information</strong>
                    </div>
                    <div class="table-responsive">
                         <table class="table table-bordered table-hover">       
                         	<thead>
                            	<tr>
									<th>Name</th>                                	
                                    <th>Gender</th>
                                    <th>Age</th>
                                    <th>Contact</th>
                                    <th>District</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>                   
                           <tbody>  
                           	   <?php
									$result = $db->prepare("select * from  rquest_register_accept where stat='pending'");
									$result->execute();
									for($i=1; $row = $result->fetch(); $i++)
										{		
											$reqrgacc_id = $row['reqrgacc_id'];								
											echo"<tr>";						
											echo"<td>".$row["uname"]."</td>";
											echo"<td>".$row["usex"]."</td>";	
											echo"<td>".$row["uage"]."</td>";	
											echo"<td>".$row["ucontact"]."</td>";
											echo"<td>".$row["udistrict"]."</td>";
											echo"<td>".$row["uemail"]."</td>";
											echo"<td>".$row["tdate"]."</td>";	
											?>
											<td>
												<a href="request_pending_more.php<?php echo '?reqrgacc_id='.$reqrgacc_id; ?>" class=" btn btn-sm btn-info">&nbsp;Processes</a>
											</td>                                                                     
											<?php										
											echo"</tr>";										
										}
									
								?>	
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>                                                   
		</section>
	</div>    
	<?php include("include/footer.php");?>
</div>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../bower_components/dist/js/adminlte.min.js"></script>
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../bower_components/fastclick/lib/fastclick.js"></script>

<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
