<?php
include('../../../connect/db.php');
		 
	 $fdbk_id=$_POST["fdbk_id"];	 
	
	 $reply=$_POST["reply"];	
	 $rdate=$_POST["rdate"];
	
	$sql = "update feedback set reply='$reply',rdate='$rdate' where fdbk_id='$fdbk_id'";
	$q1 = $db->prepare($sql);
	$q1->execute();

header("location:../feedback_search.php");
?>
