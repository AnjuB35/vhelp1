<?php
include("../../../connect/db.php");

	$mssing_id=$_POST["mssing_id"];
	$stat=$_POST["stat"];
	
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../missing_people/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	if($photo=="")
	{
		$sql = "update messing_people set stat='$stat' where mssing_id='$mssing_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	else
	{
		$sql = "update messing_people set stat='$stat',photo='$photo' where mssing_id='$mssing_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}

	header("location:../missing_view.php");
?>

