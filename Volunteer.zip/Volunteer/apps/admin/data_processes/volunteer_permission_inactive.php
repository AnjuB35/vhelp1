<?php
include('../../../connect/db.php');


	$voln_id=$_GET["voln_id"]; 	
	
	
$sql = "update volunteer set stat='Inactive' where voln_id='$voln_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../volunteer_permission.php");

?>						
