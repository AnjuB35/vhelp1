<?php
include('../../../connect/db.php');
		 
	 $cmp_id=$_POST["cmp_id"];	 
	
	 $reply=$_POST["reply"];	
	 $stat=$_POST["stat"];
	 
	 $rdate=date("Y-m-d");
	
	$sql = "update complaints set reply='$reply',stat='$stat',rdate='$rdate' where cmp_id='$cmp_id'";
	$q1 = $db->prepare($sql);
	$q1->execute();

header("location:../complaint_pending.php");
?>
