<?php
include("../../../connect/db.php");

	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$subj=$_POST["subj"]; 
	$date=$_POST["date"];
	
$sql = "insert into notification(name,cntno,subj,date)values('$name','$cntno','$subj','$date')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../notification_send.php");
?>
