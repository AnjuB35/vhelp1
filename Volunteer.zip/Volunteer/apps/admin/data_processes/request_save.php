<?php
include("../../../connect/db.php");

	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$email=$_POST["email"];
	$subj=$_POST["subj"];
	$servce=$_POST["servce"];
	$fdate=$_POST["fdate"];
	$tdate=$_POST["tdate"];
	
$sql = "insert into rquest_register(name,cntno,email,subj,servce,fdate,tdate)values('$name','$cntno','$email','$subj','$servce','$fdate','$tdate')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../request_register.php");
?>
