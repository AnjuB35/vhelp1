<?php
include('../../../connect/db.php');


	$reqrgacc_id=$_GET["reqrgacc_id"]; 	
	
	
$sql = "delete from rquest_register_accept where reqrgacc_id='$reqrgacc_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../request_remove.php");

?>						
