<?php
include("../../../connect/db.php");

	$department=$_POST["department"];
	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$email=$_POST["email"];
	$date=$_POST["date"];
	$ftime=$_POST["ftime"];
	$ttime=$_POST["ttime"];
	
	$desp=$_POST["desp"];
	
	
$sql = "insert into camp(department,name,cntno,email,date,ftime,ttime,desp)values('$department','$name','$cntno','$email','$date','$ftime','$ttime','$desp')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../camp_register.php");
?>
