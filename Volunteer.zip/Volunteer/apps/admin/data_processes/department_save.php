<?php
include("../../../connect/db.php");

	$departmnt=$_POST["departmnt"];
	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$email=$_POST["email"];
	$utype="Department";
	$password=$_POST["password"];
	$date=$_POST["date"];
	
$sql = "insert into department(departmnt, name, cntno, email, utype, password, date)values('$departmnt','$name','$cntno','$email','$utype','$password','$date')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../index.php");
?>
