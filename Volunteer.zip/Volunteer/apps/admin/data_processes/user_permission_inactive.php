<?php
include('../../../connect/db.php');


	$user_id=$_GET["user_id"]; 	
	
	
$sql = "update user set stat='Inactive' where user_id='$user_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../user_permission.php");

?>						
