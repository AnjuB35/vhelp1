<?php
include('../../../connect/db.php');
		 
	 $reqrgacc_id=$_POST["reqrgacc_id"];	 
	
	 $msg=$_POST["msg"];	
	 $stat=$_POST["stat"];
	
	$sql = "update rquest_register_accept set msg='$msg',stat='$stat' where reqrgacc_id='$reqrgacc_id'";
	$q1 = $db->prepare($sql);
	$q1->execute();

header("location:../request_pending.php");
?>
