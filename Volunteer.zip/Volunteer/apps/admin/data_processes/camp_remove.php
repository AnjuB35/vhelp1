<?php
include('../../../connect/db.php');


	$camp_id=$_GET["camp_id"]; 	
	
	
$sql = "delete from camp where camp_id='$camp_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../camp_remove.php");

?>						
