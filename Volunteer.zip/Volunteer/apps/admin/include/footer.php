<footer class="main-footer">
	<strong>Volunteer</strong>
</footer>