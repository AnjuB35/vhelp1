<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Volunteer</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
    <link rel="stylesheet" href="assets/css/font-awesome.css">
    <script src='assets/js/jquery.min.js'></script>
  </head>
  <body>
<!-- forms23 block -->
<section class="w3l-forms-23">
    <div class="forms23-block">
	<!---728x90--->

        <div class="container">
            <h1>
                <a href="index.php" class="logo-2 logo-3"><span class="fa fa-angellist"
                        aria-hidden="true"></span> Volunteer</a>             
            </h1>
            <div class="d-grid forms23-grids">
                <div class="form23">
                    <span class="fa fa-user"></span>
                    <h6>Login</h6>
                    <form action="login_log.php" method="post" autocomplete="off">
                        <input type="email" name="email" class="input-form" placeholder="Your Email"
                            required="required" />
                        <input type="password" name="password" class="input-form" placeholder="Your Password"
                            required="required" />
                        <button type="submit" class="btn button-eff">Login</button>
                    </form>
                    <p>Not a member yet? <a href="signup.php">Join Now!</a></p>
                </div>
            </div>
        </div>
		<!---728x90--->

    </div>
</section>
<!-- //forms23 block -->