<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Volunteer</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
    <link rel="stylesheet" href="assets/css/font-awesome.css">
    <script src='assets/js/jquery.min.js'></script>
  </head>
  <body>
<!-- forms23 block -->
<section class="w3l-forms-23">
    <div class="forms23-block">
	<!---728x90--->

        <div class="container">
            <h1>
                <a href="index.php" class="logo-2 logo-3"><span class="fa fa-angellist"
                    aria-hidden="true"></span> Volunteer</a>          
            </h1>
            <div class="d-grid forms23-grids">
                <div class="form23">
                    <h6>Emergency Contact</h6>
                    <form action="emergency_save.php" method="post" autocomplete="off">
                        <input type="text" name="name" class="input-form" placeholder="Name" required pattern="[a-zA-Z1 _]{3,50}" />
                        <input type="email" name="email" class="input-form" placeholder="Email" required="required" />
                        <input type="text" name="contno1" class="input-form" placeholder="Phone Number One" required pattern="[0-9]{10,10}" maxlength="10" minlength="10"/>
                        <input type="text" name="contno2" class="input-form" placeholder="Phone Number Two"  required pattern="[0-9]{10,10}" maxlength="10" minlength="10" />
                        <textarea name="neds" class="form-control" rows="4" required placeholder="Needs"></textarea>
                        <p>By contact, you agree to our <a href="#terms">Terms of Use</a></p>
                        <button type="submit" class="btn button-eff">Submit</button>
                    </form>
                </div>
            </div>
        </div>
		<!---728x90--->

    </div>
</section>
<!-- //forms23 block -->