-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 24, 2021 at 04:22 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `volunteer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `utype` varchar(100) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `username`, `password`, `utype`) VALUES
(1, 'admin@gmail.com', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `camp`
--

CREATE TABLE IF NOT EXISTS `camp` (
  `camp_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` text NOT NULL,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `email` text NOT NULL,
  `date` text NOT NULL,
  `ftime` text NOT NULL,
  `ttime` text NOT NULL,
  `desp` text NOT NULL,
  PRIMARY KEY (`camp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `camp_request`
--

CREATE TABLE IF NOT EXISTS `camp_request` (
  `camp_req_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdepartment` text NOT NULL,
  `cname` text NOT NULL,
  `ccntno` text NOT NULL,
  `cdate` text NOT NULL,
  `uname` text NOT NULL,
  `usex` text NOT NULL,
  `uage` text NOT NULL,
  `udistrict` text NOT NULL,
  `uemail` text NOT NULL,
  `ucontact` text NOT NULL,
  `ustat` text NOT NULL,
  `udate` text NOT NULL,
  PRIMARY KEY (`camp_req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `cmp_id` int(11) NOT NULL AUTO_INCREMENT,
  `departmnt` varchar(100) NOT NULL,
  `name` text NOT NULL,
  `contactno` text NOT NULL,
  `email` text NOT NULL,
  `compl` text NOT NULL,
  `date` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  `reply` text NOT NULL,
  `rdate` text NOT NULL,
  PRIMARY KEY (`cmp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `dep_id` int(11) NOT NULL AUTO_INCREMENT,
  `departmnt` text NOT NULL,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `date` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  PRIMARY KEY (`dep_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE IF NOT EXISTS `donate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `donate` text NOT NULL,
  `descp` text NOT NULL,
  `dated` text NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emergency`
--

CREATE TABLE IF NOT EXISTS `emergency` (
  `emerg_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `contno1` text NOT NULL,
  `contno2` text NOT NULL,
  `neds` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`emerg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fdbk_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `subj` text NOT NULL,
  `sdate` text NOT NULL,
  `reply` text NOT NULL,
  `rdate` text NOT NULL,
  PRIMARY KEY (`fdbk_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `helpline`
--

CREATE TABLE IF NOT EXISTS `helpline` (
  `help_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `entno` text NOT NULL,
  `email` text NOT NULL,
  `servce` text NOT NULL,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messing_people`
--

CREATE TABLE IF NOT EXISTS `messing_people` (
  `mssing_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` text NOT NULL,
  `pname` text NOT NULL,
  `name` text NOT NULL,
  `sex` text NOT NULL,
  `age` text NOT NULL,
  `addr` text NOT NULL,
  `cntno` text NOT NULL,
  `mplace` text NOT NULL,
  `mdate` text NOT NULL,
  `desp` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  PRIMARY KEY (`mssing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `not_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `subj` text NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`not_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rquest_register`
--

CREATE TABLE IF NOT EXISTS `rquest_register` (
  `reqrg_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `email` text NOT NULL,
  `subj` text NOT NULL,
  `servce` text NOT NULL,
  `fdate` text NOT NULL,
  `tdate` text NOT NULL,
  `rstat` text NOT NULL,
  `runame` text NOT NULL,
  PRIMARY KEY (`reqrg_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rquest_register_accept`
--

CREATE TABLE IF NOT EXISTS `rquest_register_accept` (
  `reqrgacc_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `email` text NOT NULL,
  `subj` text NOT NULL,
  `servce` text NOT NULL,
  `fdate` text NOT NULL,
  `tdate` text NOT NULL,
  `uname` text NOT NULL,
  `usex` text NOT NULL,
  `uage` text NOT NULL,
  `ucontact` text NOT NULL,
  `udistrict` text NOT NULL,
  `uemail` text NOT NULL,
  `stat` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`reqrgacc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `sex` text,
  `age` int(3) DEFAULT NULL,
  `blgrp` varchar(15) DEFAULT NULL,
  `addrs` text,
  `district` text,
  `location` text,
  `pinocde` text,
  `email` text,
  `contactno` text,
  `username` text,
  `password` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE IF NOT EXISTS `volunteer` (
  `voln_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `sex` text,
  `age` int(3) DEFAULT NULL,
  `blgrp` varchar(15) DEFAULT NULL,
  `addrs` text,
  `district` text,
  `location` text,
  `pinocde` text,
  `qulf` text,
  `job` text,
  `experincs` text,
  `servce` text,
  `email` text,
  `contactno` text,
  `password` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  PRIMARY KEY (`voln_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
